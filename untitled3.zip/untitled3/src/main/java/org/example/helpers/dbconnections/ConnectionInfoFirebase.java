package org.example.helpers.dbconnections;

public class ConnectionInfoFirebase {

    private String credetials;
    private String path;

    /**
     *
     * @param credetials
     * @param path
     */
    public ConnectionInfoFirebase(String credetials, String path) {
        this.credetials = credetials;
        this.path = path;
    }

    /**
     *
     * @return
     */
    public String getCredetials() {
        return credetials;
    }

    /**
     *
     * @param credetials
     */
    public void setCredetials(String credetials) {
        this.credetials = credetials;
    }

    /**
     *
     * @return
     */
    public String getPath() {
        return path;
    }

    /**
     *
     * @param path
     */
    public void setPath(String path) {
        this.path = path;
    }
}

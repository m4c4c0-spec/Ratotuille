package org.example.helpers.enums;

public enum DatabaseCredentialsFirebase{
    SEVICECONNECTION("{\n" +
            "  \"type\": \"service_account\",\n" +
            "  \"project_id\": \"ratatoulli\",\n" +
            "  \"private_key_id\": \"97f56a33a861132b73fc8cbfb496088dd48a0812\",\n" +
            "  \"private_key\": \"-----BEGIN PRIVATE KEY-----\\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDjsD0eoCjcmFOp\\nTReJzrNopgXP0Cu3rKBqjSs08bnv9ZzNFvjJ1PdIQU3RcQXL92FqZnea/1/tEOfO\\nnzD614znNwFXD+7Ulirpa3naKG2LQ1Qcp8+CclyIdT1HF+WtN1Bkq6+BMTgOmKEn\\nZPVdJ9pIKfbWgjOMLkghhFJ3cjoDreJeuyK8LA2olw18yZGhjP2ROZsu/JlrCDdX\\njC9lfU0itqohbSKDJHXVWJDXlg06wzIw/orWm1mBkeFfmjqZzepiT2tGqGzqxcpI\\nvOCsKEgADIiEaCZm3Ieuk8h6NXmIPr8UAfVShGWr7fMtl9Fvob6RhBKMbRNMWiqL\\nlkEG76FpAgMBAAECggEAbPy+/OpoNNO7dDZhNodZTJXwAT4htw1sSiSh0nmE6e51\\nLJy64Q3Ogmk0ATWrMyuKl15OEUT9m2I0u6xqyx+jpEepng2T4nGxP8NA9CLW8Mr9\\nN6xCAayRS4ZnGyE+wQ/RrSabX2l6bk40EcHbS0iYzWM88wgm+Ypr35NR0Dg+ueQ6\\nJFnEfnOQgL6zpyCT7GN/i+bczfHeme0c0iBRtHMSA2VzoRuIBV4qis2on8/SUFsO\\ni0fnCNbz3nS/kBsU3568v844Ef5FjBe4bGQ4un3Hqn+eZ3RPRl8fFPzDVDEpm4Q6\\nllwqDilzZVdi/zUMyQ+uvaOHmbm0kSSQnT1BgR9hawKBgQD9xAkxgxahHoT9Moqp\\n9lYPWjHty2MM1Erk/Caon1wqNvdFX6iJ2lJ1atlheP8RUZh6SCjmG7QRMMknL8CJ\\nkFO1bT9Kl67TfSu8FouWTbVxFlvBj2gwyb8wFGuBL26Nkcv69UH1/ixdY0GZ67fu\\n81XvhfA2ZjONBv287lpnF4jfSwKBgQDlsW1PM7SWXy1YWl56RvJdwxkeZtq8MekL\\nOD5zfQiGSKfUb/k/PcG1uQ+Kl520BObIZBqZ+w69tKCTyvTYjHYP+CTT75/AZEa0\\nIaVYNBEZed5Wlf01G/7UkU76K91xPj3vF78G52NyzyDBgu4QTlchCRpMeAPmNRiV\\nX7iDggjtmwKBgEvskzOVHPgnwXJf5MzlPupo+fdDmucDvUS1jHt28oRO3byL2kkk\\nYPdweImJQgdUemJbpKD0OPPLvONUji6aV/E4Nm+C4nO0R5mGxUy7A0ZKgjlvRqUS\\nN3mTIncMUe9ZZ8Y2Cv4mhe+K+t2qgOWlOFjpoe0kttfC97fHOJUPnYvxAoGABmVv\\ndtIoyDs0Rw6VLPCG1UeWjnsswirdo3tYedzUfPDPA6JunW051LankSNxt86fIptv\\nBjSwj2XVRuhS8yjOLNmrJN+6YiAou+Fn+lHQ3BXBtEWO/IigCwlU2rCYBQxHqz3N\\nCwMsiMjtz5W2zWtxD7FyMwjwituVqKs2tyrK1tsCgYBmPHTb9/JPLBG12DJRHYMV\\n6ykqSARchGp0iTC2Wjloas4XN/Rx6guHwbOcpgsHxl2eF+XRxeZloEYicaItUdVm\\n7mrC64TTsnfZ1tvb4Su1MbtJTQzrvYLDDepQG8PYw9Z0Srh6nKAGk/Oo2NelMYtU\\ncz50QWKxrv62uK9LAXaYhw==\\n-----END PRIVATE KEY-----\\n\",\n" +
            "  \"client_email\": \"firebase-adminsdk-hymjj@ratatoulli.iam.gserviceaccount.com\",\n" +
            "  \"client_id\": \"100283241814759141999\",\n" +
            "  \"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",\n" +
            "  \"token_uri\": \"https://oauth2.googleapis.com/token\",\n" +
            "  \"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",\n" +
            "  \"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-hymjj%40ratatoulli.iam.gserviceaccount.com\",\n" +
            "  \"universe_domain\": \"googleapis.com\"\n" +
            "}"),
    URLDATABASE("https://ratatoulli.firebaseio.com/");

    private final String VALUE;

    /**
     *
     * @param VALUE
     */
    private DatabaseCredentialsFirebase(String VALUE) {
        this.VALUE = VALUE;
    }

    /**
     *
     * @return
     */
    public String getVALUE() {
        return VALUE;
    }
}

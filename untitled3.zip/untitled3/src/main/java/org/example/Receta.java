package org.example;

import java.util.ArrayList;

public class Receta {
    private String nombre;
    private ArrayList<String> ingredientes;
    private int tiempo; //tiene que estar en minutos
    private int dificultad;//es de 1-5 donde 1 es muy facil y 5 es muy dificil
    private String descripcion;

    public Receta(String nombre, ArrayList<String> ingredientes, int tiempo, int dificultad, String descripcion) {
        this.nombre = nombre;
        this.ingredientes = ingredientes;
        this.tiempo = tiempo;
        this.dificultad = dificultad;
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Receta{" +
                "nombre='" + nombre + '\'' +
                ", ingredientes=" + ingredientes +
                ", tiempo=" + tiempo +
                ", dificultad=" + dificultad +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }

    public String getNombre() {
        return nombre;
    }
}

package org.example;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import org.example.databases.firestore.DatabaseConnectionFirebase;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class Funciones {
    private final Firestore database;

    public Funciones(DatabaseConnectionFirebase database) {
        this.database = database.getConnection();
    }
    /**
     * Esta es la función "mostrarTodasLasResetas" lo que hace es mostrar todas las recetas ordenadas
     * en el orden natural de las cosas, es decir usando el orden del diccionario.
     *
     */
    public void mostrarTodasLasResetas(){
            try {
                String collectionName = "receta"; // Nombre fijo de la colección

                // Consultar todos los documentos de la colección
                ApiFuture<QuerySnapshot> future = database.collection(collectionName).get();
                QuerySnapshot querySnapshot = future.get();

                if (querySnapshot.isEmpty()) {
                    System.out.println("No se encontraron documentos en la colección: " + collectionName);
                } else {
                    // Iterar y mostrar todos los documentos
                    for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                        System.out.println("ID del documento: " + document.getId());
                        System.out.println("Datos del documento: " + document.getData());
                        System.out.println("--------------");
                    }
                }
            } catch (InterruptedException | ExecutionException e) {
                Thread.currentThread().interrupt();
                System.out.println("Error al leer documento(s): " + e.getMessage());
            }
    }

    /**
     * Esta es la función "busquedaFiltrada" lo que hace es buscar la receta según ciertos parametros
     * como lo son ingrediente, tiempo o difucultad.
     * Para ingrediente se debe ingresar dos ingredientes como minimo, de tal forma buscar las recetas
     * que tengan estos mismo ingrediente, y en el caso de que falten ingredientes mostrarlos de un
     * color diferente.
     * Para tiempo mostrar las recetas que duren esta cantidad de tiempo que esta en minutos.
     * Para dificultad mostrar las recetas que tiene esta dificultad siendo 1 la menor dificultad, y
     * 5 la dificultad más alta.
     */
    public void busquedaFiltrada(int tipoFiltro){
        if (tipoFiltro==1){
            System.out.println("Aqui se mostraran la busqueda que fue filtrada");

            try {
                String collectionName = "receta"; // Nombre de la colección

                System.out.print("Ingrese los ingredientes separados por coma: ");
                String ingredientesInput = org.example.Main.teclado.nextLine().trim();

                // Convertir los ingredientes ingresados a una lista
                List<String> ingredientesBuscados = Arrays.stream(ingredientesInput.split(","))
                        .map(String::trim)
                        .filter(value -> !value.isEmpty())
                        .collect(Collectors.toList());

                if (ingredientesBuscados.size() < 2) {
                    System.out.println("Debe ingresar al menos dos ingredientes. Faltan parámetros.");
                    return;
                }

                ApiFuture<QuerySnapshot> future = database.collection(collectionName).get();
                QuerySnapshot querySnapshot = future.get();

                if (querySnapshot.isEmpty()) {
                    System.out.println("No se encontraron documentos en la colección: " + collectionName);
                } else {
                    querySnapshot.getDocuments().stream()
                            .filter(document -> {
                                // Obtener el campo "ingredientes" del documento
                                Object ingredientesField = document.get("ingredientes");
                                if (ingredientesField instanceof String) {
                                    // Convertir a lista
                                    List<String> ingredientesDocumento = Arrays.stream(((String) ingredientesField).split(","))
                                            .map(String::trim)
                                            .collect(Collectors.toList());
                                    // Validar si contiene todos los ingredientes buscados
                                    return ingredientesBuscados.stream().allMatch(ingredientesDocumento::contains);
                                }
                                return false;
                            })
                            .forEach(document -> {
                                System.out.println("ID del documento: " + document.getId());
                                Object ingredientesField = document.get("ingredientes");
                                List<String> ingredientesDocumento = Arrays.stream(((String) ingredientesField).split(","))
                                        .map(String::trim)
                                        .collect(Collectors.toList());

                                // Ingredientes presentes
                                List<String> presentes = ingredientesBuscados.stream()
                                        .filter(ingredientesDocumento::contains)
                                        .collect(Collectors.toList());

                                // Ingredientes faltantes
                                List<String> faltantes = ingredientesDocumento.stream()
                                        .filter(ingrediente -> !ingredientesBuscados.contains(ingrediente))
                                        .collect(Collectors.toList());

                                // Mostrar resultados
                                System.out.println("Ingredientes ingresados presentes: " + presentes);
                                System.out.println("Ingredientes faltantes en el documento: " + faltantes);
                                System.out.println("--------------");
                            });
                }
            } catch (InterruptedException | ExecutionException e) {
                Thread.currentThread().interrupt();
                System.out.println("Error al leer documento(s): " + e.getMessage());
            }
        } else if (tipoFiltro==2) {



        //ingredientes filtrar con programación funcional y tranformar el ArratList de ingredientes a una Lista
            try {
                String collectionName = "receta"; // Nombre fijo de la colección
                String fieldName = "tiempo";     // Campo fijo para buscar por tiempo

                System.out.print("Ingrese el tiempo en minutos: ");
                String input = org.example.Main.teclado.nextLine().trim();

                // Validar que el valor ingresado es un número
                int tiempo;
                try {
                    tiempo = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    System.out.println("Debe ingresar un número válido para el tiempo en minutos.");
                    return;
                }

                // Consultar todos los documentos de la colección
                ApiFuture<QuerySnapshot> future = database.collection(collectionName).get();
                QuerySnapshot querySnapshot = future.get();

                if (querySnapshot.isEmpty()) {
                    System.out.println("No se encontraron documentos en la colección: " + collectionName);
                } else {
                    // Filtrar y mostrar solo los documentos que tienen el tiempo indicado
                    boolean encontrado = false;
                    for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                        Object fieldValue = document.get(fieldName);
                        if (fieldValue instanceof Number && ((Number) fieldValue).intValue() == tiempo) {
                            encontrado = true;
                            System.out.println("ID del documento: " + document.getId());
                            System.out.println("Datos del documento: " + document.getData());
                            System.out.println("--------------");
                        }
                    }
                    if (!encontrado) {
                        System.out.println("No se encontraron recetas con tiempo: " + tiempo + " minutos.");
                    }
                }
            } catch (InterruptedException | ExecutionException e) {
                Thread.currentThread().interrupt();
                System.out.println("Error al leer documento(s): " + e.getMessage());
            }
        } else if (tipoFiltro==3) {


            //tiempo-duración es solo un numero en minutos

            try {
                String collectionName = "receta"; // Nombre fijo de la colección
                String fieldName = "dificultad";  // Campo fijo para buscar por dificultad

                System.out.print("Ingrese el nivel de dificultad (número): ");
                String input = org.example.Main.teclado.nextLine().trim();

                // Validar que el valor ingresado es un número
                int dificultad;
                try {
                    dificultad = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    System.out.println("Debe ingresar un número válido para la dificultad.");
                    return;
                }

                // Consultar todos los documentos de la colección
                ApiFuture<QuerySnapshot> future = database.collection(collectionName).get();
                QuerySnapshot querySnapshot = future.get();

                if (querySnapshot.isEmpty()) {
                    System.out.println("No se encontraron documentos en la colección: " + collectionName);
                } else {
                    // Filtrar y mostrar solo los documentos que tienen la dificultad indicada
                    boolean encontrado = false;
                    for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                        Object fieldValue = document.get(fieldName);
                        if (fieldValue instanceof Number && ((Number) fieldValue).intValue() == dificultad) {
                            encontrado = true;
                            System.out.println("ID del documento: " + document.getId());
                            System.out.println("Datos del documento: " + document.getData());
                            System.out.println("--------------");
                        }
                    }
                    if (!encontrado) {
                        System.out.println("No se encontraron recetas con dificultad: " + dificultad);
                    }
                }
            } catch (InterruptedException | ExecutionException e) {
                Thread.currentThread().interrupt();
                System.out.println("Error al leer documento(s): " + e.getMessage());
            }
        }
        //dificultad tiempo/60 Ningredientes/(tiempo/60)=dificultad

    }

    /**
     * Esta es la función "buscarPorNombre" que busca la receta según el nombre que tiene, muestra el
     * nombre de la receta, los ingrediente a ocupar, el tiempo que necesita aproximadamente, la
     * dificultad de implica al hacerla, y la descripción que son la instruciones para poder hacerla.
     */
    public void buscarPorNombre() {
        System.out.println("Aquí se mostrarán las búsquedas por nombre");
            try {
                String collectionName = "receta"; // Nombre fijo de la colección

                System.out.print("Ingrese el nombre de la receta (ID del documento): ");
                String recetaId = org.example.Main.teclado.nextLine().trim();

                if (recetaId.isEmpty()) {
                    System.out.println("El nombre de la receta (ID del documento) no puede estar vacío.");
                    return;
                }

                // Referencia al documento por su ID
                DocumentReference docRef = database.collection(collectionName).document(recetaId);
                ApiFuture<DocumentSnapshot> future = docRef.get();
                DocumentSnapshot document = future.get();

                if (document.exists()) {
                    // Mostrar los datos del documento encontrado
                    System.out.println("ID del documento: " + document.getId());
                    System.out.println("Datos del documento: " + document.getData());
                    System.out.println("--------------");
                } else {
                    System.out.println("No se encontró una receta con el nombre (ID del documento): " + recetaId);
                }
            } catch (InterruptedException | ExecutionException e) {
                Thread.currentThread().interrupt();
                System.out.println("Error al leer documento: " + e.getMessage());
            }

    }

    /**
     * Esta es la funcion "generarArchivo" que es para generar el archivo de alguna reseta, por lo
     * que primero se pide el nombre de la receta para poder generar una "receta#.txt".
     */
    public void generarArchivo(){
        System.out.println("aqui se genererara un archivo para que pueda leerlo en otro momento");
        try {
            System.out.print("Ingrese el nombre del documento (ID de la receta): ");
            String recetaId = Main.teclado.nextLine().trim();

            if (recetaId.isEmpty()) {
                System.out.println("El ID del documento no puede estar vacío.");
                return;
            }

            // Referencia al documento en Firestore
            DocumentReference docRef = database.collection("receta").document(recetaId);
            ApiFuture<DocumentSnapshot> future = docRef.get();
            DocumentSnapshot document = future.get();

            if (document.exists()) {
                // Preparar los datos del documento para escribirlos en un archivo
                String datosReceta = "ID: " + document.getId() + "\n" +
                        "Datos: " + document.getData().toString();

                // Crear y escribir en el archivo .txt
                String fileName = recetaId + ".txt"; // El archivo tendrá el nombre del ID
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                    writer.write(datosReceta);
                }

                System.out.println("Receta exportada exitosamente al archivo: " + fileName);
            } else {
                System.out.println("No se encontró una receta con el ID: " + recetaId);
            }
        } catch (IOException e) {
            System.out.println("Error al crear el archivo: " + e.getMessage());
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            System.out.println("Error al consultar Firestore: " + e.getMessage());
        }

    }
}

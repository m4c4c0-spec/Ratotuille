package org.example.interfaces;

import org.example.CRUD;
import org.example.Main;
import org.example.databases.firestore.DatabaseConnectionFirebase;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InterfaceCRUD extends Frame {
    private Button ButtonCrear,ButtonLeer,ButtonActualizar,ButtonEliminar;


    public InterfaceCRUD(DatabaseConnectionFirebase database){
        CRUD crud = new CRUD(database);


        setTitle("CRUD");//Este es el titulo
        setSize(600, 400);//Dimenciones Largo-Ancho
        setLayout(null);//Establese un diseño

        ButtonCrear = new Button("CREATE");
        ButtonCrear.setBounds(150, 110, 150, 50);
        add(ButtonCrear);

        ButtonLeer = new Button("READ");
        ButtonLeer.setBounds(150, 170, 150, 50);
        add(ButtonLeer);

        ButtonActualizar = new Button("UPDATE");
        ButtonActualizar.setBounds(150, 230, 150, 50);
        add(ButtonActualizar);

        ButtonEliminar = new Button("DELETE");
        ButtonEliminar.setBounds(150, 290, 150, 50);
        add(ButtonEliminar);

        ButtonCrear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               Main.teclado.nextLine();
               crud.crear();
            }
        });

        ButtonLeer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                crud.leer();
            }
        });

        ButtonActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                crud.actualizar();
            }
        });

        ButtonEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                crud.eliminar();
            }
        });

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        }) ;
    }

}

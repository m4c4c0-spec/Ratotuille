package org.example;

import org.example.databases.firestore.DatabaseConnectionFirebase;
import org.example.interfaces.InterfaceCRUD;
import org.example.interfaces.InterfaceUsuario;

import java.util.Scanner;

public class Main {
    public static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args) {

        DatabaseConnectionFirebase databaseConnectionFirebase = new DatabaseConnectionFirebase();
        System.out.println("Instancia creada: "+databaseConnectionFirebase.getConnection());

        CRUD crud = new CRUD(databaseConnectionFirebase);
        Funciones funciones = new Funciones(databaseConnectionFirebase);

        funciones.busquedaFiltrada(1);

        try {
            System.out.println("¿Usted es un usuario?");
            System.out.println("1--> Si soy");
            System.out.println("2--> No soy");
            System.out.println("para finalizar ingrese cualquier numero");
            int pregunta;
            pregunta = teclado.nextInt();
            if (pregunta == 1) {
                InterfaceUsuario app = new InterfaceUsuario(databaseConnectionFirebase);
                app.setVisible(true);
            } else if (pregunta == 2) {
                InterfaceCRUD a = new InterfaceCRUD(databaseConnectionFirebase);
                a.setVisible(true);
            }
        }catch (Exception e){
            System.err.println("Parametro ingresado no es un número");
        }
    }
}
package org.example.test;

import org.example.databases.firestore.DatabaseConnectionFirebase;
import org.example.helpers.dbconnections.ConnectionInfoFirebase;
import org.example.helpers.enums.DatabaseCredentialsFirebase;
import com.google.cloud.firestore.Firestore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class DatabaseConnectionFirebaseTest {

    private DatabaseConnectionFirebase dbConnection;

    @BeforeEach
    public void setUp() {
        // Inicializar la conexión antes de cada prueba
        dbConnection = new DatabaseConnectionFirebase();
    }

    @Test
    public void testConnection() {
        // Crear la información de conexión a Firebase
        ConnectionInfoFirebase connectionInfo = new ConnectionInfoFirebase(
                DatabaseCredentialsFirebase.SEVICECONNECTION.getVALUE(),
                DatabaseCredentialsFirebase.URLDATABASE.getVALUE()
        );

        // Crear la conexión
        String connectionResult = dbConnection.createConnection(connectionInfo);

        // Comprobar que la conexión fue exitosa
        assertNotNull(connectionResult, "La conexión no debe ser nula");
        assert(connectionResult.contains("Success"), "La conexión debe ser exitosa");

        // Obtener la conexión Firestore y comprobar que no es nula
        Firestore firestore = dbConnection.getConnection();
        assertNotNull(firestore, "La conexión a Firestore no debe ser nula");
    }
}

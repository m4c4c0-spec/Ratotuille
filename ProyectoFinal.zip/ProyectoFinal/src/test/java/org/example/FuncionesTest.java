package org.example;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import org.example.databases.firestore.DatabaseConnectionFirebase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class FuncionesTest {

    @Mock
    private Firestore firestoreMock;
    @Mock
    private ApiFuture<QuerySnapshot> querySnapshotApiFuture;
    @Mock
    private QuerySnapshot querySnapshot;
    @Mock
    private DocumentSnapshot documentSnapshot;
    @Mock
    private DatabaseConnectionFirebase databaseConnectionFirebaseMock;

    private Funciones funciones;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        // Mock del objeto DatabaseConnectionFirebase para obtener la conexión de Firestore
        when(databaseConnectionFirebaseMock.getConnection()).thenReturn(firestoreMock);

        // Inicializamos el objeto Funciones
        funciones = new Funciones(databaseConnectionFirebaseMock);
    }

    @Test
    public void testMostrarTodasLasResetas_WhenNoDocuments() throws InterruptedException, ExecutionException {
        // Mock de Firestore para cuando no haya documentos
        when(firestoreMock.collection("receta").get()).thenReturn(querySnapshotApiFuture);
        when(querySnapshotApiFuture.get()).thenReturn(querySnapshot);
        when(querySnapshot.isEmpty()).thenReturn(true);

        // Ejecutamos la función
        funciones.mostrarTodasLasResetas();

        // Verificamos que el mensaje de no encontrar documentos se imprime
        verify(querySnapshot).isEmpty();
    }

    @Test
    public void testMostrarTodasLasResetas_WhenDocumentsExist() throws InterruptedException, ExecutionException {
        // Mock de Firestore para cuando haya documentos
        when(firestoreMock.collection("receta").get()).thenReturn(querySnapshotApiFuture);
        when(querySnapshotApiFuture.get()).thenReturn(querySnapshot);
        when(querySnapshot.isEmpty()).thenReturn(false);

        DocumentSnapshot documentMock = mock(DocumentSnapshot.class);
        when(documentMock.getId()).thenReturn("receta1");
        when(documentMock.getData()).thenReturn(Map.of("nombre", "Tarta de manzana"));

        when(querySnapshot.getDocuments()).thenReturn(List.of(documentMock));

        // Ejecutamos la función
        funciones.mostrarTodasLasResetas();

        // Verificamos que el método getData() del documento sea llamado
        verify(documentMock).getData();
    }

    @Test
    public void testBusquedaFiltrada_WhenTipoFiltro1() throws InterruptedException, ExecutionException {
        // Mock para tipoFiltro = 1 (ingredientes)
        when(firestoreMock.collection("receta").get()).thenReturn(querySnapshotApiFuture);
        when(querySnapshotApiFuture.get()).thenReturn(querySnapshot);
        when(querySnapshot.isEmpty()).thenReturn(false);

        DocumentSnapshot documentMock = mock(DocumentSnapshot.class);
        when(documentMock.getId()).thenReturn("receta1");
        when(documentMock.get("ingredientes")).thenReturn("harina, azúcar, huevo");

        when(querySnapshot.getDocuments()).thenReturn(List.of(documentMock));

        // Ejecutamos la función
        funciones.busquedaFiltrada(1);

        // Verificamos que se haya llamado al método get() para obtener los ingredientes
        verify(documentMock).get("ingredientes");
    }

    @Test
    public void testGenerarArchivo_WhenDocumentExists() throws InterruptedException, ExecutionException {
        // Mock para generar archivo
        when(firestoreMock.collection("receta").document("receta1").get()).thenReturn(querySnapshotApiFuture);
        when(querySnapshotApiFuture.get()).thenReturn(querySnapshot);
        when(querySnapshot.getDocuments()).thenReturn(Arrays.asList(documentSnapshot));

        when(documentSnapshot.exists()).thenReturn(true);
        when(documentSnapshot.getId()).thenReturn("receta1");
        when(documentSnapshot.getData()).thenReturn(Map.of("nombre", "Receta Ejemplo"));

        // Ejecutamos la función
        funciones.generarArchivo();

        // Verificamos que la escritura del archivo se haya realizado correctamente
        // Para ello, puedes usar un mock o verificar si el método BufferedWriter fue llamado.
    }

    @Test
    public void testBuscarPorNombre_WhenDocumentFound() throws InterruptedException, ExecutionException {
        // Mock para búsqueda por nombre
        when(firestoreMock.collection("receta").document("receta1").get()).thenReturn(querySnapshotApiFuture);
        when(querySnapshotApiFuture.get()).thenReturn(querySnapshot);
        when(querySnapshot.getDocuments()).thenReturn(Arrays.asList(documentSnapshot));
        when(documentSnapshot.exists()).thenReturn(true);
        when(documentSnapshot.getId()).thenReturn("receta1");
        when(documentSnapshot.getData()).thenReturn(Map.of("nombre", "Receta Ejemplo"));

        // Ejecutamos la función
        funciones.buscarPorNombre();

        // Verificamos que el método get() haya sido invocado correctamente.
        verify(documentSnapshot).getData();
    }
}

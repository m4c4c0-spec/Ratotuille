package org.example;

import com.google.cloud.firestore.Firestore;
import org.example.databases.firestore.DatabaseConnectionFirebase;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class CRUDTest {

    private final InputStream originalSystemIn = System.in;
    private DatabaseConnectionFirebase mockDatabaseConnection;
    private CRUD crud;

    @BeforeEach
    public void setUp() {
        // Simular una conexión ficticia a Firestore
        mockDatabaseConnection = new DatabaseConnectionFirebase() {
            @Override
            public Firestore getConnection() {
                return null; // Simula una conexión si es necesario
            }
        };

        crud = new CRUD(mockDatabaseConnection);
    }

    @AfterEach
    public void tearDown() {
        // Restaurar System.in
        System.setIn(originalSystemIn);
    }

    @Test
    public void testCrear() {
        String simulatedInput = """
                receta
                ChocolateCake
                field1
                value1
                field2
                value2
                fin
                """;

        ByteArrayInputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        // Invocar el método crear
        crud.crear();
    }

    @Test
    public void testLeer() {
        String simulatedInput = """
                receta
                ChocolateCake
                field1
                value1,value2
                """;

        ByteArrayInputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        // Invocar el método leer
        crud.leer();
    }

    @Test
    public void testActualizar() {
        String simulatedInput = """
                receta
                ChocolateCake
                field1
                updatedValue1
                fin
                """;

        ByteArrayInputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        // Invocar el método actualizar
        crud.actualizar();
    }

    @Test
    public void testEliminar() {
        String simulatedInput = """
                receta
                ChocolateCake
                """;

        ByteArrayInputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        // Invocar el método eliminar
        crud.eliminar();
    }
}

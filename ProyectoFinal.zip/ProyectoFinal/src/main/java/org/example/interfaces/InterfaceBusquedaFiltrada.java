package org.example.interfaces;

import org.example.Funciones;
import org.example.databases.firestore.DatabaseConnectionFirebase;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class InterfaceBusquedaFiltrada extends Frame {
    private Button ButtonPorIngrediente,ButtonPorTiempo,ButtonPorDificultad;
    public InterfaceBusquedaFiltrada(DatabaseConnectionFirebase database){
        Funciones funciones = new Funciones(database);

        setTitle("Filtrado de Recetas");//Nombre del titulo
        setSize(600, 400);//Dimenciones Largo-Ancho
        setLayout(null);//Establese un diseño


        ButtonPorIngrediente = new Button("Filtrado por ingrediente");
        ButtonPorIngrediente.setBounds(50, 50, 150, 50); // x, y, ancho, alto
        add(ButtonPorIngrediente);

        ButtonPorTiempo = new Button("Filtrado por tiempo");
        ButtonPorTiempo.setBounds(50, 110, 150, 50); // x, y, ancho, alto
        add(ButtonPorTiempo);

        ButtonPorDificultad = new Button("Filtrado por dificultad");
        ButtonPorDificultad.setBounds(50, 170, 150, 50); // x, y, ancho, alto
        add(ButtonPorDificultad);

        ButtonPorIngrediente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                funciones.busquedaFiltrada(1);
            }
        });

        ButtonPorTiempo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                funciones.busquedaFiltrada(2);
            }
        });

        ButtonPorDificultad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                funciones.busquedaFiltrada(3);
            }
        });

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        }) ;
    }
}

package org.example.interfaces;

import org.example.Funciones;
import org.example.Main;
import org.example.databases.firestore.DatabaseConnectionFirebase;

import java.awt.*;
import java.awt.event.*;

public class InterfaceUsuario extends Frame {
    private Label LabelBienbenida;
    private Button ButtonVerReceta,ButtonBucarFiltrado,ButtonBuscarPorNombre,ButtonGenerarArchivo;


    public InterfaceUsuario(DatabaseConnectionFirebase database) {
        Funciones funciones = new Funciones(database);
        InterfaceBusquedaFiltrada app = new InterfaceBusquedaFiltrada(database);

        setTitle("Menu");//Nombre del titulo
        setSize(600, 400);//Dimenciones Largo-Ancho
        setLayout(null);//Establese un diseño

        LabelBienbenida = new Label("Bienvenido y gracios por apoyarnos");
        LabelBienbenida.setBounds(125,50,300,50);
        add(LabelBienbenida);


        //Botones personalizados
        ButtonVerReceta = new Button("Ver todas las recetas");
        ButtonVerReceta.setBounds(150, 110, 150, 50);
        add(ButtonVerReceta);

        ButtonBucarFiltrado = new Button("Buscar de forma filtrada");
        ButtonBucarFiltrado.setBounds(150, 170, 150, 50);
        add(ButtonBucarFiltrado);

        ButtonBuscarPorNombre = new Button("Buscar por nombre");
        ButtonBuscarPorNombre.setBounds(150, 230, 150, 50);
        add(ButtonBuscarPorNombre);

        ButtonGenerarArchivo = new Button("Generar archivo");
        ButtonGenerarArchivo.setBounds(150, 290, 150, 50);
        add(ButtonGenerarArchivo);

        ButtonVerReceta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Main.teclado.nextLine();
                funciones.mostrarTodasLasResetas();
            }
        });

        ButtonBucarFiltrado.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                app.setVisible(true);
            }
        });

        ButtonBuscarPorNombre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                funciones.buscarPorNombre();
            }
        });

        ButtonGenerarArchivo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                funciones.generarArchivo();
            }
        });


        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        }) ;

    }
}

package org.example;

import org.example.databases.firestore.DatabaseConnectionFirebase;
import org.example.interfaces.InterfaceCRUD;
import org.example.interfaces.InterfaceUsuario;

import java.util.Scanner;

public class Main {
    //se inicializa el Scanner para que se puedan ingresar datos por teclado
    public static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args) {

        //se incicializa la conección a la base de datos
        DatabaseConnectionFirebase databaseConnectionFirebase = new DatabaseConnectionFirebase();
        System.out.println("Instancia creada: "+databaseConnectionFirebase.getConnection());

        //Estes es un mini menu para despues motror las interfaces correcpondiente
        try {
            System.out.println("¿Usted es un usuario?");
            System.out.println("1--> Si soy");
            System.out.println("2--> No soy");
            System.out.println("para finalizar ingrese cualquier numero");
            int pregunta;
            pregunta = teclado.nextInt();
            if (pregunta == 1) {
                //se muestre la interface usuario en caso de ser usuario
                InterfaceUsuario app = new InterfaceUsuario(databaseConnectionFirebase);
                app.setVisible(true);
            } else if (pregunta == 2) {
                //se muestra la clase CRUD para los desarrolladores
                InterfaceCRUD a = new InterfaceCRUD(databaseConnectionFirebase);
                a.setVisible(true);
            }
            //en caso de que lo ingresado no sea un número lo lleva a esto
        }catch (Exception e){
            System.err.println("Parametro ingresado no es un número");
        }
    }
}
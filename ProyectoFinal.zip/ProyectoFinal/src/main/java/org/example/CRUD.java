package org.example;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import org.example.databases.firestore.DatabaseConnectionFirebase;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class CRUD {
    private final Firestore database;

    public CRUD(DatabaseConnectionFirebase database) {
        this.database = database.getConnection();
    }

    // Create: Agregar un documento a una colección
    public void crear() {
        try {
            //el nombre de la colección tiene que ser receta para caso de este proyecto
            System.out.print("Ingrese el nombre de la colección: ");
            String collectionName = Main.teclado.nextLine().trim();

            //en caso de tener el nombre de la coleeción vacio termina la función
            if (collectionName.isEmpty()) {
                System.err.println("El nombre de la colección no puede estar vacío.");
                return;
            }

            //la id del documento es el nombre de la receta
            System.out.println("deje vacio para crear una ID automatica");
            System.out.print("Ingrese el ID del documento: ");
            String documentId = Main.teclado.nextLine().trim();

            //Se inicializa la función para crear datos de forma dinamica
            Map<String, Object> data = collectData();
            //En caso de no ingresar nada se cancela la funcioón
            if (data.isEmpty()) {
                System.err.println("No se agregaron datos. Operación cancelada.");
                return;
            }

            DocumentReference docRef;
            if (documentId.isEmpty()) {
                // Generar automáticamente el ID
                ApiFuture<DocumentReference> future = database.collection(collectionName).add(data);
                docRef = future.get();
                System.out.println("Documento creado con ID: " + docRef.getId());
            } else {
                // Usar el ID proporcionado
                docRef = database.collection(collectionName).document(documentId);
                ApiFuture<WriteResult> future = docRef.set(data);
                future.get();
                System.out.println("Documento creado con ID: " + documentId);
            }
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            System.err.println("Error al crear documento: " + e.getMessage());
        }
    }

    // Read: Leer un documento por ID
    public void leer() {
        try {
            //se debe ingresar receta en caso de este proyecto
            System.out.print("Ingrese el nombre de la colección: ");
            String collectionName = Main.teclado.nextLine().trim();

            if (collectionName.isEmpty()) {
                System.err.println("El nombre de la colección no puede estar vacío.");
                return;
            }

            System.out.println("deje vacia para mostrar todos los documentos");
            System.out.print("Ingrese el ID del documento: ");
            String documentId = Main.teclado.nextLine().trim();

            System.out.println("deje vacio para mostrar todos los campos");
            System.out.print("Ingrese el nombre del campo que desea mostrar: ");
            String fieldName = Main.teclado.nextLine().trim();

            System.out.println("deje vacio para mostrar todos los valores");
            System.out.println("Ejemplo: valor1,valor2,...");
            System.out.print("Ingrese los valores que desea buscar: ");
            String fieldValuesInput = Main.teclado.nextLine().trim();

            // Convertir los valores a una lista, eliminando espacios en blanco
            List<String> fieldValues = Arrays.stream(fieldValuesInput.split(","))
                    .map(String::trim)
                    .filter(value -> !value.isEmpty())
                    .collect(Collectors.toList());

            if (documentId.isEmpty()) {
                // Leer todos los documentos de la colección
                ApiFuture<QuerySnapshot> future = database.collection(collectionName).get();
                QuerySnapshot querySnapshot = future.get();

                if (querySnapshot.isEmpty()) {
                    System.err.println("No se encontraron documentos en la colección: " + collectionName);
                } else {
                    querySnapshot.getDocuments().stream()
                            .filter(document -> {
                                if (fieldName.isEmpty() || fieldValues.isEmpty()) {
                                    return true; // Mostrar todos si no hay filtro
                                }
                                Object fieldValue = document.get(fieldName);
                                if (fieldValue instanceof String) {
                                    List<String> documentValues = Arrays.stream(((String) fieldValue).split(","))
                                            .map(String::trim)
                                            .collect(Collectors.toList());
                                    return fieldValues.stream().allMatch(documentValues::contains);
                                }
                                return false;
                            })
                            .forEach(document -> {
                                System.out.println("ID del documento: " + document.getId());
                                if (fieldName.isEmpty()) {
                                    System.out.println("Datos del documento: " + document.getData());
                                } else {
                                    Object fieldValue = document.get(fieldName);
                                    if (fieldValue != null) {
                                        System.out.println(fieldName + ": " + fieldValue);
                                    } else {
                                        System.err.println("El campo \"" + fieldName + "\" no existe en este documento.");
                                    }
                                }
                                System.out.println("--------------");
                            });
                }
            } else {
                // Leer un solo documento por ID
                DocumentReference docRef = database.collection(collectionName).document(documentId);
                ApiFuture<DocumentSnapshot> future = docRef.get();
                DocumentSnapshot document = future.get();

                if (document.exists()) {
                    if (fieldName.isEmpty()) {
                        System.out.println("Datos del documento: " + document.getData());
                    } else {
                        Object fieldValue = document.get(fieldName);
                        if (fieldValue instanceof String) {
                            List<String> documentValues = Arrays.stream(((String) fieldValue).split(","))
                                    .map(String::trim)
                                    .collect(Collectors.toList());
                            if (fieldValues.isEmpty() || fieldValues.stream().allMatch(documentValues::contains)) {
                                System.out.println(fieldName + ": " + fieldValue);
                            } else {
                                System.err.println("El documento no cumple con los valores ingresados.");
                            }
                        } else {
                            System.err.println("El campo \"" + fieldName + "\" no existe o no es un String.");
                        }
                    }
                } else {
                    System.err.println("No se encontró el documento con ID: " + documentId);
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            System.err.println("Error al leer documento(s): " + e.getMessage());
        }
    }



    // Update: Actualizar un documento existente
    public void actualizar() {
        try {
            //Para casos de este proyecto tiene que ser receta
            System.out.print("Ingrese el nombre de la colección: ");
            String collectionName = Main.teclado.nextLine().trim();

            //Se tiene que ingresar el nombre de la receta
            System.out.print("Ingrese el ID del documento: ");
            String documentId = Main.teclado.nextLine().trim();

            if (collectionName.isEmpty() || documentId.isEmpty()) {
                System.err.println("El nombre de la colección o el ID del documento no pueden estar vacíos.");
                return;
            }

            //Se inicializa la función para crear datos de forma dinamica
            Map<String, Object> updates = collectData();
            //Esto es en caso de no ingresar datos
            if (updates.isEmpty()) {
                System.err.println("No se realizaron actualizaciones. Operación cancelada.");
                return;
            }

            DocumentReference docRef = database.collection(collectionName).document(documentId);
            ApiFuture<WriteResult> future = docRef.update(updates);
            WriteResult result = future.get();
            System.out.println("Documento actualizado en: " + result.getUpdateTime());

        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            System.err.println("Error al actualizar documento: " + e.getMessage());
        }
    }

    // Delete: Eliminar un documento por ID
    public void eliminar() {
        try {
            System.out.print("Ingrese el nombre de la colección: ");
            String collectionName = Main.teclado.nextLine().trim();

            System.out.print("Ingrese el ID del documento: ");
            String documentId = Main.teclado.nextLine().trim();

            if (collectionName.isEmpty() || documentId.isEmpty()) {
                System.err.println("El nombre de la colección o el ID del documento no pueden estar vacíos.");
                return;
            }

            DocumentReference docRef = database.collection(collectionName).document(documentId);
            ApiFuture<WriteResult> future = docRef.delete();
            WriteResult result = future.get();
            System.out.println("Documento eliminado en: " + result.getUpdateTime());
        } catch (InterruptedException | ExecutionException e) {
            //cuando interumpe el hilo y no hace la operación por entrar en un estado de espera
            Thread.currentThread().interrupt();
            System.err.println("Error al eliminar documento: " + e.getMessage());
        }
    }

    // Método auxiliar para recolectar datos dinámicamente
    private Map<String, Object> collectData() {
        Map<String, Object> data = new HashMap<>();

        System.out.println("Ingrese las claves y valores para el documento.");
        System.out.println("Escriba 'fin' para terminar.");

        while (true) {
            System.out.print("Campo: ");
            String campo = Main.teclado.nextLine().trim();
            if ("fin".equalsIgnoreCase(campo)) break;

            if (campo.isEmpty()) {
                System.err.println("El campo no puede estar vacío. Intente nuevamente.");
                continue;
            }

            System.out.print("Valor: ");
            String valor = Main.teclado.nextLine().trim();
            Object parsedValue = parseValue(valor);
            data.put(campo, parsedValue);
        }
        return data;
    }

    // Método auxiliar para determinar el tipo de valor ingresado
    private Object parseValue(String input) {
        if (input.startsWith("[") && input.endsWith("]")) {
            String arrayContent = input.substring(1, input.length() - 1).trim();
            String[] items = arrayContent.split("\\s*,\\s*");
            return List.of(items);
        }

        try {
            if (input.matches("^-?\\d+$")) return Integer.parseInt(input);
            if (input.matches("^-?\\d+\\.\\d+$")) return Double.parseDouble(input);
            if ("true".equalsIgnoreCase(input) || "false".equalsIgnoreCase(input)) return Boolean.parseBoolean(input);
        } catch (NumberFormatException ignored) {}

        return input; // Por defecto, tratar como String
    }
}
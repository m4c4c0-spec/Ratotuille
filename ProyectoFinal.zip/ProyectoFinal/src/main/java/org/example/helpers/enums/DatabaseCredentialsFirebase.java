package org.example.helpers.enums;

public enum DatabaseCredentialsFirebase{
    SEVICECONNECTION("{\n" +
            "  \"type\": \"service_account\",\n" +
            "  \"project_id\": \"ratatoulli\",\n" +
            "  \"private_key_id\": \"d6be63cf5e9cd5aac0c52e47730d7e3aecb886f3\",\n" +
            "  \"private_key\": \"-----BEGIN PRIVATE KEY-----\\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCyWaXKDr/fDAuX\\nhaI91Lv+kR5gifkdQ1qa6fPashikz3D6hB4vS2+katNHjro/+4xwfbmeCopfZiCq\\n0/VgGhoRdSSn1NXm3g0hjBrrC8jXCG20FBsBIGeNTOhd3hqKoQa2JQszYoWqBIRd\\nFMi+/WA3txL6EfnvTQxQE/fhvZ45PfpT0qpNs5bTtu5WQgq+x6F5vt3FaqzU9GMI\\n3A0hNZhxF3W9MMUguLEsAEagTFVQJ7WS18e2VuBeDhcGZPSHqURWvj8aNgGO0z8o\\nru03jOPVW/EFi6h7OCeZCuvKeYEFl1R2qjB1O0gySPgaWA1SMM7fCsndhhAXhUbE\\n+MG/uvZ3AgMBAAECggEACf83aUuJWr3Imo4tiWy2uu60drHVKlw/pGZPumb4NajB\\nCvHD5V/DmsI4JI8uBm8ZsKaDdIXfurg1RY4K93+PDYJ08wldkgrJTqOVUK6A6/i3\\neXwVBWulEkkIz1YnQ7UB9My/w3oWxvBo4PTMydPXBFh5MlY2ncDCW2y7HMatq0Sj\\ndk0X2A506Gwy44ccIk2MHJp20Og7GB7DfS/9fosfoQQa6k/uVqC+Jlkcafj/mUAH\\n46gaoH7KLmNwCoDhqXoI5ubKd+e2S/p3duL8jjLCjBCNLDpsdzUOhIQ6xrNAy3V2\\nSK8P3JpatALGNGY+U9jRexNvnf4fNdYXIeXh79s4SQKBgQDw9FKhrDUpbRyMIyPz\\n/hILJh8SBPQ8WSPwUml0srEfzy2YUQMCsBTHPz6/z8Zq/3cc3jwH8ahJeE6Rv+7G\\npo+zVK3pBGBrF9cp8FmQBUSyJRphQ51M2JqD9WAs6AhA06E29+GAbh3lDiAJzq5M\\nj+Og92OXyZydQ7MnbE1S8YfwXwKBgQC9fJdVl1VQUHg28ToyY+gd/9GYBGfOBAer\\nIPe453QMMA+14VXjtknAqbuD4b4CaPeZY6p36ahOIWSd+92etuy6/+zE+wbO9/6G\\npeMLXpTwTFndwQ2ibe4LOdP7ELagNfxEBdDWhOMbRGRt/L6kxdhttj/5SWp2WX8y\\nDvkllMzQ6QKBgHwsjUEALE1zC5k0qtyc/NN+C9kPcIaBMcIx1mLri9hmvoqWhUSn\\nVa3w6/eRriGKEepwpOM7KIzkUSlPjlAVmkzCwPUq6j2Ghb35PU65SFO+R0AExlXJ\\n8qc6lxvNYCN4bMaVLEMxfHqEswIa3zxZkudrVonsvqdVMkiIybiK/JFlAoGBAJgp\\nuQ1OnYAFXsQgKu/UMs4EZLeCsilKKy5NJyEhHJu87KDN9z8JX2iL5L0fRoqA6HQR\\nCQ+KX1F+l2IWo/2UP75bTjNQskL5+zb9d7nllgzyAyiEowJQ7Nuu8H+pCD7Xm2C0\\nmuPpisaWwV9hm2aOSiKwO+dgAVJQxEfaplB7kY4hAoGALvcZUAULy7RO2L4NvJn6\\nMLW0ugo2ZhkP/1G6ybq4UexRD/uRBld+pSI+vGUve8B25CzZJYNu6hsY3j6bNPye\\noFS/o8wj85Gq6AExCB2CA0ic+2KJ/Gm5vA4DQMa5dDj9NY6vbJWScpR+p11TD+eu\\nb38tgNJrfcsgdsDasg0nUSE=\\n-----END PRIVATE KEY-----\\n\",\n" +
            "  \"client_email\": \"firebase-adminsdk-hymjj@ratatoulli.iam.gserviceaccount.com\",\n" +
            "  \"client_id\": \"100283241814759141999\",\n" +
            "  \"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",\n" +
            "  \"token_uri\": \"https://oauth2.googleapis.com/token\",\n" +
            "  \"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",\n" +
            "  \"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-hymjj%40ratatoulli.iam.gserviceaccount.com\",\n" +
            "  \"universe_domain\": \"googleapis.com\"\n" +
            "}"),
    URLDATABASE("https://ratatoulli.firebaseio.com/");

    private final String VALUE;

    private DatabaseCredentialsFirebase(String VALUE) {
        this.VALUE = VALUE;
    }

    public String getVALUE() {
        return VALUE;
    }
}
